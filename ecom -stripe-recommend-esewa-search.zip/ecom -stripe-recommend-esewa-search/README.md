# Ecommerce-website-with-Recommendation-System

### Import Database
  Firstly import the database "shopping_db" before running the website
### Admin and user credentials
  The admin and user cresentials are given in installation-steps.txt fole
### Payment credentials
  The payment credentials are given in the esewa credentials.txt
  

<?php
	include 'database.php';
    $base_url = "http://localhost/ecom";
    

?>
<?php 
include 'config.php'; 
include 'header.php'; 
?>

<?php 
    //include ("./config_pay.php");
    require_once "stripe-php-master/init.php";
    
    //require_once "product.php";
    //require_once "index_pay.php";
    

    $stripeDetails = array(
        
        "publishableKey"=>"pk_test_51Mfar8G8IMG50CI54Kgqf9bXWLaTTGsiE37NlR2Et3GY9W05LJv1LBhv0oXb6XDxI7VZF4HZ43DC9s9wjDPRsTXu00K35cEroa",
        "secretKey"=>"sk_test_51Mfar8G8IMG50CI5hYWqcplyQ0Gm7jqXRPuaqZ6XO3wgmcQtmi8HMWqo5OwnM52pzvTNTz47Pxd4CM9z5ZriQ7xB00iReWxqhj"

    );

    \Stripe\Stripe::setApiKey($stripeDetails['secretKey']);
?>

<div class="product-cart-container">
    <div class="container">
        <div class="row">
            <div class="col-md-12 clearfix">
                <h2 class="section-head">My Cart</h2>
                <?php
                if (isset($_COOKIE['user_cart'])) {
                    $pid = json_decode($_COOKIE['user_cart']);
                    if (is_object($pid)) {
                        $pid = get_object_vars($pid);
                    }

                    if (!empty($pid)) {
                        $pids = implode(',', $pid);
                        $db = new Database();
                        $db->select('products', '*', null, 'product_id IN (' . $pids . ')', null, null);
                        $result = $db->getResult();

                        if (count($result) > 0) { ?>
                            <table class="table table-bordered">
                                <thead>
                                    <th>Product Image</th>
                                    <th>Product Name</th>
                                    <th width="120px">Product Price</th>
                                    <th width="100px">Qty.</th>
                                    <th width="100px">Sub Total</th>
                                    <th>Action</th>
                                </thead>
                                <tbody>
                                    <?php 
                                    foreach ($result as $row) {
                                        $quantity = isset($_COOKIE['cart_qty_' . $row['product_id']]) ? $_COOKIE['cart_qty_' . $row['product_id']] : 1;
                                    ?>
                                        <tr class="item-row">
                                            <td>
                                                <img src="product-images/<?php echo $row['featured_image']; ?>" alt="" width="70px" />
                                            </td>
                                            <td><?php echo $row['product_title']; ?></td>
                                            <td><?php echo $cur_format; ?> <span class="product-price"><?php echo $row['product_price']; ?></span></td>
                                            <td>
                                                <input class="form-control positiveInput item-qty" type="number" min="1" step="any" value="<?php echo $quantity; ?>" />
                                                <input type="hidden" class="item-id" value="<?php echo $row['product_id']; ?>" />
                                                <input type="hidden" class="item-price" value="<?php echo $row['product_price']; ?>" />
                                            </td>
                                            <td><?php echo $cur_format; ?> <span class="sub-total"><?php echo $row['product_price'] * $quantity; ?></span></td>
                                            <td>
                                                <a class="btn btn-sm btn-primary remove-cart-item" href="" data-id="<?php echo $row['product_id']; ?>"><i class="fa fa-remove"></i></a>
                                            </td>
                                        </tr>
                                    <?php } ?>
                                    <tr>
                                        <td colspan="4" align="right"><b>TOTAL AMOUNT (<?php echo $cur_format; ?>)</b></td>
                                        <td class="total-amount"></td>
                                        <td></td>
                                    </tr>
                                </tbody>
                            </table>
                            <a class="btn btn-sm btn-primary" href="<?php echo $hostname; ?>">Continue Shopping</a>
                            <?php if (isset($_SESSION['user_role'])) { ?>
                                <form action="success.php" class="checkout-form pull-right" method="POST">
                                    <?php
                                    $product_id = '';
                                    $product_qty = ''; // Initialize product quantities
                                    foreach ($result as $row) {
                                        $product_id .= $row['product_id'] . ',';
                                        $quantity = isset($_COOKIE['cart_qty_' . $row['product_id']]) ? $_COOKIE['cart_qty_' . $row['product_id']] : 1;
                                        $product_qty .= $quantity . ','; // Append quantities
                                    }
                                    ?>
                                    <input type="hidden" name="pid" value="<?php echo rtrim($product_id, ','); ?>">
                                    <input type="hidden" name="amt" id="amt" class="total-price" value="">
                                    <input type="hidden" name="product_qty" value="<?php echo rtrim($product_qty, ','); ?>"> <!-- Pass quantities -->
                                    <!-- <input type="submit" class="btn btn-md btn-success" value="Proceed to Checkout"> -->
                                    <?php //echo $row['product_price'] * $quantity; ?>    
                                    <script
                                        src="https://checkout.stripe.com/checkout.js" class="stripe-button"
                                        data-key="pk_test_51Mfar8G8IMG50CI54Kgqf9bXWLaTTGsiE37NlR2Et3GY9W05LJv1LBhv0oXb6XDxI7VZF4HZ43DC9s9wjDPRsTXu00K35cEroa"
                                        data-amount="<?php echo ($row['product_price'] * $quantity) * 100;?>"
                                        data-currency="npr"
                                        data-locale="auto">
                                    </script>

                                </form>
                            <?php } else { ?>
                                <a class="btn btn-sm btn-success pull-right" href="#" data-toggle="modal" data-target="#userLogin_form">Proceed to Checkout</a>
                            <?php } ?>
                        <?php }
                    } else { ?>
                        <div class="empty-result">
                            Your cart is currently empty.
                            <a class="btn btn-sm btn-primary" href="<?php echo $hostname; ?>">Continue Shopping</a>
                        </div>
                    <?php }
                } else { ?>
                    <div class="empty-result">
                        Your cart is currently empty.
                        <a class="btn btn-sm btn-primary" href="<?php echo $hostname; ?>">Continue Shopping</a>
                    </div>
                <?php } ?>
            </div>
        </div>
    </div>
</div>

<script>
    document.querySelectorAll(".positiveInput").forEach((inputField) => {
        // Validate and update quantity on input
        inputField.addEventListener("input", function () {
            const row = inputField.closest("tr");
            const price = parseFloat(row.querySelector(".item-price").value);
            const quantity = parseFloat(inputField.value) || 1;

            if (isNaN(quantity) || quantity < 1) {
                inputField.value = 1; // Enforce minimum value
            }

            // Update subtotal
            const subtotal = price * inputField.value;
            row.querySelector(".sub-total").textContent = subtotal.toFixed(2);

            // Recalculate total amount
            calculateTotal();

            // Save quantity in a cookie
            const productId = row.querySelector(".item-id").value;
            document.cookie = `cart_qty_${productId}=${inputField.value};path=/`;
        });
    });

    // Calculate and display the total amount
    function calculateTotal() {
        let total = 0;
        document.querySelectorAll(".sub-total").forEach((subtotalField) => {
            total += parseFloat(subtotalField.textContent) || 0;
        });
        document.querySelector(".total-amount").textContent = total.toFixed(2);

        // Update hidden total input for checkout
        document.querySelector(".total-price").value = total.toFixed(2);
    }
</script>

<?php include 'footer.php'; ?>

<?php
session_start();
error_reporting(E_ALL); // Enable all error reporting for debugging

// Database connection
$servername = "127.0.0.1:3306";
$username = "root";
$password = "";
$dbname = "shopping_db";

$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Debugging: Print POST data
//echo "<pre>";
//print_r($_POST);
//echo "</pre>";

// Ensure POST data exists
if (isset($_POST['pid']) && isset($_POST['product_qty'])) {
    $product_ids = $_POST['pid']; // Comma-separated product IDs
    $product_qty = $_POST['product_qty']; // Comma-separated quantities

    // Convert strings to arrays
    $product_id_array = explode(",", $product_ids);
    $product_qty_array = explode(",", $product_qty);

    // Debugging: Validate input arrays
    //echo "Product IDs: ";
    //print_r($product_id_array);
    //echo "<br>Quantities: ";
    //print_r($product_qty_array);
    //echo "<br>";

    // Check if the arrays have the same length
    if (count($product_id_array) == count($product_qty_array)) {
        for ($i = 0; $i < count($product_id_array); $i++) {
            $product_id = $product_id_array[$i];
            $quantity_to_deduct = (int)$product_qty_array[$i];

            // Fetch product details
            $sql = "SELECT qty FROM `products` WHERE product_id = '$product_id'";
            $result = $conn->query($sql);

            if ($result && $result->num_rows > 0) {
                $row = $result->fetch_assoc();
                $current_quantity = (int)$row['qty'];

                // Check if sufficient quantity is available
                if ($current_quantity >= $quantity_to_deduct) {
                    $new_quantity = $current_quantity - $quantity_to_deduct;

                    // Update the quantity in the database
                    $update_sql = "UPDATE `products` SET `qty` = '$new_quantity' WHERE product_id = '$product_id'";
                    if ($conn->query($update_sql)) {
                       // echo "Product ID $product_id updated successfully. New quantity: $new_quantity<br>";
                    } else {
                        echo "Error updating Product ID $product_id: " . $conn->error . "<br>";
                    }
                } else {
                    echo "Insufficient stock for Product ID $product_id. Available: $current_quantity, Required: $quantity_to_deduct<br>";
                }
            } else {
                echo "Product ID $product_id not found.<br>";
            }
        }
    } else {
        echo "Mismatch between the number of product IDs and quantities.<br>";
    }
} else {
    echo "No product data received.<br>";
}

// Clear cart cookies after purchase
if (isset($_COOKIE['user_cart'])) {
    setcookie('cart_count', '', time() - 180, '/');
    setcookie('user_cart', '', time() - 180, '/');
    //echo "Cart cookies cleared.<br>";
}

// Close database connection
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Payment Successful</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="css/font-awesome.css">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="payment-response">
        <div class="container">
            <div class="row">
                <div class="col-md-offset-3 col-md-6">
                    <div class="panel panel-default">
                        <div class="panel-body text-center">
                            <i class="fa fa-check-circle text-success" style="font-size: 3em;"></i>
                            <h3>Payment Successful</h3>
                            <p>Your product(s) will be delivered within 2 to 3 days.</p>
                            <a href="index.php" class="btn btn-sm btn-primary add-order">Continue Shopping</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</body>
</html>

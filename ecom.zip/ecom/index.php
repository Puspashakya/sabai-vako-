<?php include 'config.php';  //include config
// set dynamic title
$db = new Database();
$db->select('options', 'site_title', null, null, null, null);
$result = $db->getResult();

if (!empty($result)) {
    $title = $result[0]['site_title'];
} else {
    $title = "Bajra Store";
}
// include header 
include 'header.php'; ?>
<div id="banner">
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12">
                <div class="banner-content ">
                    <div class="banner-carousel owl-carousel owl-theme">
                        <div class="item">
                            <img src="images/banner-img-2.jpg" alt="" />
                        </div>
                        <div class="item">
                            <img src="images/banner-img-1.jpg" alt="" />
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="product-section">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h2 class="section-head">Latest Products</h2>
                <div class="latest-carousel owl-carousel owl-theme">
                    <?php
                    $db = new Database();
                    $db->select('products', '*', null, null, 'product_id DESC', 6);
                    $result = $db->getResult();
                    if (count($result) > 0) {
                        foreach ($result as $row) { ?>
                            <div class="product-grid latest item">
                                <div class="product-image popular">
                                    <a class="image" href="single_product.php?pid=<?php echo $row['product_id']; ?>">
                                        <img class="pic-1" src="product-images/<?php echo $row['featured_image']; ?>">
                                    </a>
                                    <div class="product-button-group">
                                        <a href="single_product.php?pid=<?php echo $row['product_id']; ?>"><i class="fa fa-eye"></i></a>
                                        <a href="" class="add-to-cart" data-id="<?php echo $row['product_id']; ?>"><i class="fa fa-shopping-cart"></i></a>
                                        <a href="" class="add-to-wishlist" data-id="<?php echo $row['product_id']; ?>"><i class="fa fa-heart"></i></a>
                                    </div>
                                </div>
                                <div class="product-content">
                                    <h3 class="title">
                                        <a href="single_product.php?pid=<?php echo $row['product_id']; ?>"><?php echo substr($row['product_title'], 0, 25), '...'; ?></a>
                                    </h3>
                                    <div class="price"><?php echo $cur_format; ?> <?php echo $row['product_price']; ?></div>
                                </div>
                            </div>
                    <?php    }
                    } ?>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="product-section popular-products">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h2 class="section-head">Popular Products</h2>
                <div class="popular-carousel owl-carousel owl-theme">
                    <?php
                    $db->select('products', '*', null, 'product_views > 0', 'product_views DESC', 10);
                    $result = $db->getResult();
                    if (count($result) > 0) {
                        foreach ($result as $row) { ?>
                            <div class="product-grid latest item">
                                <div class="product-image popular">
                                    <a class="image" href="single_product.php?pid=<?php echo $row['product_id']; ?>">
                                        <img class="pic-1" src="product-images/<?php echo $row['featured_image']; ?>">
                                    </a>
                                    <div class="product-button-group">
                                        <a href="single_product.php?pid=<?php echo $row['product_id']; ?>"><i class="fa fa-eye"></i></a>
                                        <a href="" class="add-to-cart" data-id="<?php echo $row['product_id']; ?>"><i class="fa fa-shopping-cart"></i></a>
                                        <a href="" class="add-to-wishlist" data-id="<?php echo $row['product_id']; ?>"><i class="fa fa-heart"></i></a>
                                    </div>
                                </div>
                                <div class="product-content">
                                    <h3 class="title">
                                        <a href="single_product.php?pid=<?php echo $row['product_id']; ?>"><?php echo substr($row['product_title'], 0, 25), '...'; ?></a>
                                    </h3>
                                    <div class="price"><?php echo $cur_format; ?> <?php echo $row['product_price']; ?></div>
                                </div>
                            </div>
                    <?php    }
                    } else {
                    } ?>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="product-section popular-products">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                    <h2 class="section-head">Recommended for you</h2>
                        <div class="popular-carousel owl-carousel owl-theme">
<?php
        $db = new Database();

// Check for cart data
if (isset($_COOKIE['user_cart']) && !empty($_COOKIE['user_cart'])) {
    $cartItems = json_decode($_COOKIE['user_cart']);
    if (is_object($cartItems)) {
        $cartItems = get_object_vars($cartItems);
    }
    $cartItemIDs = implode(',', $cartItems);

    // Debugging: Verify cart item IDs
    //echo "Cart Item IDs: " . $cartItemIDs . "<br>";

    // Fetch product details based on cart item IDs
    $db->select('products', 'product_cat, product_sub_cat', null, 'product_id IN (' . $cartItemIDs . ')', null, null);
    $cartProductResults = $db->getResult();

    // Debugging: Verify cart product results
    //echo '<pre>'; print_r($cartProductResults); echo '</pre>';

    // Extract categories and subcategories for filtering related products
    $categoryIDs = [];
    $subCategoryIDs = [];
    foreach ($cartProductResults as $item) {
        $categoryIDs[] = $item['product_cat'];
        $subCategoryIDs[] = $item['product_sub_cat'];
    }

    // Remove duplicates
    $categoryIDs = array_unique($categoryIDs);
    $subCategoryIDs = array_unique($subCategoryIDs);

    // Build a WHERE condition to fetch related products from the same category or subcategory
    $relatedConditions = [];
    if (!empty($categoryIDs)) {
        $relatedConditions[] = 'product_cat IN (' . implode(',', $categoryIDs) . ')';
    }
    if (!empty($subCategoryIDs)) {
        $relatedConditions[] = 'product_sub_cat IN (' . implode(',', $subCategoryIDs) . ')';
    }

    // Combine the conditions to form the query
    $whereClause = implode(' OR ', $relatedConditions);

    // Fetch related products based on category or subcategory
    $db->select('products', '*', null, $whereClause . ' AND product_id NOT IN (' . $cartItemIDs . ') AND product_status = 1', null, null);
    $relatedProducts = $db->getResult();

    // Debugging: Verify related products result
    //echo '<pre>Related Products: '; print_r($relatedProducts); echo '</pre>';

    // Display related products
    if (count($relatedProducts) > 0) {
        foreach ($relatedProducts as $row) { ?>
            <div class="product-grid latest item">
                <div class="product-image popular">
                    <a class="image" href="single_product.php?pid=<?php echo $row['product_id']; ?>">
                        <img class="pic-1" src="product-images/<?php echo $row['featured_image']; ?>">
                    </a>
                    <div class="product-button-group">
                        <a href="single_product.php?pid=<?php echo $row['product_id']; ?>"><i class="fa fa-eye"></i></a>
                        <a href="" class="add-to-cart" data-id="<?php echo $row['product_id']; ?>"><i class="fa fa-shopping-cart"></i></a>
                        <a href="" class="add-to-wishlist" data-id="<?php echo $row['product_id']; ?>"><i class="fa fa-heart"></i></a>
                    </div>
                </div>
                <div class="product-content">
                    <h3 class="title">
                        <a href="single_product.php?pid=<?php echo $row['product_id']; ?>"><?php echo substr($row['product_title'], 0, 25), '...'; ?></a>
                    </h3>
                    <div class="price"><?php echo $cur_format; ?> <?php echo $row['product_price']; ?></div>
                </div>
            </div>
        <?php }
    } else { ?>
        <div>No related products found.</div>
    <?php }
} else { ?>
    <div>Please continue browsing to get more recommendations.</div>
<?php } ?>
</div>



            </div>
        </div>
    </div>
</div>
<?php include 'footer.php'; ?>
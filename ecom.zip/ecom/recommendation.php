<div class="product-section popular-products">
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <h2 class="section-head">Recommended for you</h2>
                <div class="popular-carousel owl-carousel owl-theme">
                    <?php
                    // Database connection
                    $conn = new mysqli('localhost', 'root', '', 'shopping_db');
                    
                    // Check connection
                    if ($conn->connect_error) {
                        die("Connection failed: " . $conn->connect_error);
                    }

                    // User ID (Replace with dynamic user ID logic)
                    $user_id = 1;

                    // Step 1: Fetch category IDs of products in the user's cart
                    $cart_query = "
                        SELECT DISTINCT p.product_cat 
                        FROM cart c 
                        INNER JOIN products p ON c.product_id = p.product_id 
                        WHERE c.user_id = $user_id";
                    $cart_result = $conn->query($cart_query);

                    if ($cart_result->num_rows > 0) {
                        $categories = [];
                        while ($row = $cart_result->fetch_assoc()) {
                            $categories[] = $row['product_cat'];
                        }
                        $category_ids = implode(",", $categories);

                        // Step 2: Fetch recommended products from the same categories
                        $recommend_query = "
                            SELECT * FROM products 
                            WHERE product_cat IN ($category_ids) 
                            AND product_id NOT IN (
                                SELECT product_id FROM cart WHERE user_id = $user_id
                            )
                            LIMIT 10";
                        $recommend_result = $conn->query($recommend_query);

                        // Step 3: Display recommendations
                        if ($recommend_result->num_rows > 0) {
                            while ($row = $recommend_result->fetch_assoc()) { ?>
                                <div class="product-grid latest item">
                                    <div class="product-image popular">
                                        <a class="image" href="single_product.php?pid=<?php echo $row['product_id']; ?>">
                                            <img class="pic-1" src="product-images/<?php echo $row['featured_image']; ?>">
                                        </a>
                                        <div class="product-button-group">
                                            <a href="single_product.php?pid=<?php echo $row['product_id']; ?>"><i class="fa fa-eye"></i></a>
                                            <a href="" class="add-to-cart" data-id="<?php echo $row['product_id']; ?>"><i class="fa fa-shopping-cart"></i></a>
                                            <a href="" class="add-to-wishlist" data-id="<?php echo $row['product_id']; ?>"><i class="fa fa-heart"></i></a>
                                        </div>
                                    </div>
                                    <div class="product-content">
                                        <h3 class="title">
                                            <a href="single_product.php?pid=<?php echo $row['product_id']; ?>">
                                                <?php echo substr($row['product_title'], 0, 25) . '...'; ?>
                                            </a>
                                        </h3>
                                        <div class="price"><?php echo isset($cur_format) ? $cur_format : '₹'; ?> <?php echo $row['product_price']; ?></div>
                                    </div>
                                </div>
                            <?php }
                        } else {
                            echo "<p>No recommendations available.</p>";
                        }
                    } else {
                        echo "<p>No products in cart.</p>";
                    }
                    $conn->close();
                    ?>
                </div>
            </div>
        </div>
    </div>
</div>

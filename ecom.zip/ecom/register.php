<?php
include 'config.php';
session_start();
if(isset($_SESSION['user_id']) && $_SESSION['user_role'] == 'user') {
    include 'config.php';
    header("Location: " . $hostname."/user_profile.php");
}else{

include 'header.php'; ?>
<div class="container">
    <div class="row">
        <div class="col-md-offset-3 col-md-6">
           
            <!-- Form -->
            <form id="register_sign_up" class="signup_form" method ="POST" autocomplete="off">
                <h2>register here</h2>
                <div class="form-group">
                    <label>First Name</label>
                    <!-- <input type="text" name="f_name" class="form-control first_name" placeholder="First Name" requried /> -->
                    <input type="text" name="f_name" class="form-control first_name" placeholder="First Name" required oninput="this.value = this.value.replace(/[^A-Za-z]/g, '')" />

                </div>
                <div class="form-group">
                    <label>Last Name</label>
                    <input type="text" name="l_name" class="form-control last_name" placeholder="Last Name" requried oninput="this.value = this.value.replace(/[^A-Za-z]/g, '')" />
                </div>
                <div class="form-group">
                    <label>Username / Email</label>
                    <!-- <input type="email" name="username" class="form-control user_name" placeholder="Email Address" requried /> -->
                    <input type="email" name="username" class="form-control user_name" placeholder="Email Address" required pattern="[a-zA-Z0-9._%+-]+@gmail\.com" title="Please enter a valid Gmail address (e.g., example@gmail.com)" />

                </div>
                <div class="form-group">
                    <label>Password</label>
                    <!-- <input type="password" name="password" class="form-control pass_word" placeholder="Password" requried /> -->
                    <input type="password" name="password" class="form-control pass_word" placeholder="Password" required pattern="(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}" title="Password must be at least 8 characters long, include at least one uppercase letter, one lowercase letter, one number, and one special character." />
 
                </div>
                <div class="form-group">
                    <label>Mobile</label>
                    <!-- <input type="phone" name="mobile" class="form-control mobile" placeholder="Mobile" requried />  -->
                    <input type="tel" name="mobile" class="form-control mobile" placeholder="Mobile" required pattern="\d{10}" title="Please enter exactly 10 digits." />
 
                </div>
                <div class="form-group">
                    <label>Address</label>
                    <input type="text" name="address" class="form-control address" placeholder="Address" requried>
                </div>
                <div class="form-group">
                    <label>City</label>
                    <input type="text" name="city" class="form-control city" placeholder="City" requried>
                </div>
                <input type="submit" name="signup" class="btn" value="sign up"/>
            </form>
            <!-- /Form -->
        </div>
    </div>
</div>
    <?php include 'footer.php';
}
?>